/*

Example to test Sensirion SHT31 Humidity and Temperature Sensor

Communication by I2C, address 0x44

Required libraries:
.- Adafruit BusIO by Adafruit
.- Adafruit SHT31 Library by Adafruit

*/


#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_SHT31.h>
#include <Adafruit_I2CDevice.h>


Adafruit_SHT31 sht31;


void setup() {
	
  // Init serial port
  Serial.begin(74880); 
  Serial.println("");
  Serial.println("Init");
  
  // Init SHT31 sensor
  sht31 = Adafruit_SHT31();
  sht31.begin(0x44);

  Serial.println("Setup done!");
}


void loop() {
	
  // Get and show temperature and humidity
  Serial.printf("Temperature: %.2f C\n", sht31.readTemperature());
  Serial.printf("Humidity: %.2f %%\n", sht31.readHumidity());
  
  // wait 5 seconds for next scan
  delay(5000);           

}
